"""
Core module for the Python project.
"""

__version__ = "0.1.0"
