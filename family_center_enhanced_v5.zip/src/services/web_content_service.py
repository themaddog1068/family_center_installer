"""Simplified Web Content Service for Family Center Installer"""

import logging
from typing import List, Optional

logger = logging.getLogger(__name__)


class WebContentTarget:
    """Represents a web content target for screenshot capture."""

    def __init__(
        self,
        name: str,
        url: str,
        selector: str = "body",
        enabled: bool = True,
        weight: float = 1.0,
    ):
        self.name = name
        self.url = url
        self.selector = selector
        self.enabled = enabled
        self.weight = weight


class WebContentService:
    """Simplified web content service for the installer."""

    def __init__(self):
        self.targets: List[WebContentTarget] = []
        self.browser = None
        logger.info("Simplified WebContentService initialized")

    def get_target_by_name(self, name: str) -> Optional[WebContentTarget]:
        """Get a target by name."""
        for target in self.targets:
            if target.name == name:
                return target
        return None

    def add_target(self, target: WebContentTarget) -> None:
        """Add a new target."""
        self.targets.append(target)

    def remove_target(self, target: WebContentTarget) -> None:
        """Remove a target."""
        if target in self.targets:
            self.targets.remove(target)

    def cleanup_old_screenshots(self, target_name: str) -> None:
        """Clean up old screenshots for a target (simplified)."""
        logger.info(f"Would cleanup screenshots for {target_name}")

    def save_targets_to_config(self) -> None:
        """Save targets to configuration (simplified)."""
        logger.info("Would save targets to configuration") 