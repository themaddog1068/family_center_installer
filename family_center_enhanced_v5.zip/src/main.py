#!/usr/bin/env python3
"""Family Center - Main Application Entry Point"""

import logging
import os
import sys
import yaml
from pathlib import Path

# Add the src directory to the Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.modules.web_interface import WebInterface
from src.config.config_manager import ConfigManager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/family_center.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

def load_default_config():
    """Load default configuration"""
    return {
        "web": {
            "host": "0.0.0.0",
            "port": 8080,
            "debug": False
        },
        "slideshow": {
            "slide_duration_seconds": 5,
            "shuffle_enabled": True,
            "transitions": {
                "enabled": True,
                "type": "crossfade",
                "duration_seconds": 0.3,
                "ease_type": "linear"
            },
            "video_playback": {
                "enabled": True
            },
            "weighted_media": {
                "time_based_weighting": {
                    "enabled": False,
                    "day_of_week_enabled": False
                }
            }
        },
        "google_drive": {
            "folder_id": "",
            "credentials_file": ""
        },
        "sync": {
            "auto_sync_enabled": True,
            "interval_minutes": 30
        }
    }

def main():
    """Main application entry point"""
    try:
        logger.info("Starting Family Center application...")
        
        # Ensure directories exist
        os.makedirs("logs", exist_ok=True)
        os.makedirs("credentials", exist_ok=True)
        os.makedirs("media", exist_ok=True)
        
        # Load configuration
        config = load_default_config()
        
        # Try to load from config file if it exists
        config_file = "src/config/config.yaml"
        if os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    file_config = yaml.safe_load(f)
                    if file_config:
                        config.update(file_config)
                        logger.info("Loaded configuration from file")
            except Exception as e:
                logger.warning(f"Could not load config file: {e}")
        
        # Create and start web interface
        web_interface = WebInterface(config)
        logger.info("Family Center web interface initialized")
        
        # Start the web interface
        web_interface.run()
        
    except KeyboardInterrupt:
        logger.info("Family Center stopped by user")
    except Exception as e:
        logger.error(f"Error starting Family Center: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 