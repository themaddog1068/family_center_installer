"""Validation utilities."""


# ... existing code ...
