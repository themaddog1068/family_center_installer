"""Photo management for Family Center"""


class PhotoManager:
    def __init__(self, config):
        self.config = config

    def load_photos(self):
        """Load photos from Google Drive"""
        pass

    def get_next_photo(self):
        """Get next photo for slideshow"""
        pass
