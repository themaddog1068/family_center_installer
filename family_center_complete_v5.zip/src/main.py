#!/usr/bin/env python3
"""
Family Center - Digital Photo Frame and Family Dashboard
Version 5.0 - Self-contained installer version
"""

import argparse
import logging
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from modules.calendar_service import CalendarService
from modules.news_service import NewsService
from modules.photo_manager import PhotoManager
from modules.weather_service import WeatherService
from modules.web_interface import WebInterface
from utils.config_manager import ConfigManager


def setup_logging():
    """Setup logging configuration"""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler("logs/family_center.log"),
            logging.StreamHandler(),
        ],
    )


def main():
    """Main application entry point"""
    parser = argparse.ArgumentParser(description="Family Center Application")
    parser.add_argument(
        "--web-only", action="store_true", help="Run web interface only"
    )
    parser.add_argument(
        "--config", default="src/config/config.yaml", help="Configuration file path"
    )
    args = parser.parse_args()

    # Setup logging
    setup_logging()
    logger = logging.getLogger(__name__)

    try:
        # Load configuration
        config = ConfigManager(args.config)

        if args.web_only:
            logger.info("Starting Family Center in web-only mode")
            web_interface = WebInterface(config)
            web_interface.run()
        else:
            logger.info("Starting Family Center full application")
            # Initialize services
            PhotoManager(config)
            WeatherService(config)
            NewsService(config)
            CalendarService(config)
            web_interface = WebInterface(config)

            # Start web interface
            web_interface.run()

    except Exception as e:
        logger.error(f"Application failed to start: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
