"""Network utilities."""


# ... existing code ...
