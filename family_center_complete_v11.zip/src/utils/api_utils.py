"""API utilities."""


# ... existing code ...
